public class Stack  //creates linked list, implemented as simple stack
{
  static Nodes headNode = null;
  static Nodes tailNode = null;
  private static int counter = 0;
  
  public boolean isEmpty() //determines whether list contains any nodes
  {
    if(headNode == null)
      return true;
    else
      return false;
  }
  
  /* void return type
   * parameter: Nodes object
   * will add newNode to end of list (top of stack) */
  
  public static void push(Nodes newNode) 
  {
    if(headNode == null) //if head has no pointer
    {
      headNode = newNode;
    }
    else
    {
      tailNode.nextNode = newNode; //update the old tailNode
    }
    tailNode = newNode; //specify a new tailNode
    counter++;
  }
  
  public static int getCount() //returns # of nodes in list
  {
   return counter; 
  }
public static String getNodeName(Nodes nameNode)
  {
    Nodes currentNode = nameNode;
    String getNN = "";
    getNN = (currentNode.name); 
    currentNode = currentNode.nextNode;
    return getNN;
  } 
  
}
