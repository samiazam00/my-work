import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class ProgramMethods 
{  
  int num;
  int input;
  String user = UserMethods.returnUser();
  
  /* randomShows() - no parameters, void return type
   * purpose is to create linked list using nodes & stacks class to
   * choose a random show to recommend
   *  */
  public String[] randomShows() throws IOException
  { 
    Scanner tvf = new Scanner(new File("TVShowsList.txt"));
    int x = 0;
    String allShows[] = new String[66];
    while(tvf.hasNextLine())
    { 
      String tt = tvf.nextLine();
      tvf.nextLine(); // skip past other information in file
      tvf.nextLine();  // we only want show name 
      tvf.nextLine();
      tvf.nextLine();
      tvf.nextLine();
      Nodes shownode = new Nodes(tt, null);
      Stack.push(shownode);
      allShows[x] = tt;
      x++;
    }
    tvf.close();
    int randomIndx = (int)(Math.random() *(allShows.length));
    System.out.println("Show recommendation: " + allShows[randomIndx] + "\n"); 
    return allShows;
   }  
  
  /* void return type & no parameters 
   * fuction of addReview() is to prompt user for input, then add input (review of a show) to file 
   */
  public void addReview() throws IOException 
  {
    Scanner kbReader = new Scanner(System.in); 
    String user = UserMethods.returnUser();
    String showtitle = returnTitle();
    FileWriter f = new FileWriter(user + "_Reviews.txt", true);
    PrintWriter p = new PrintWriter(f); 
    System.out.println("Type your review below. You may press the enter key to submit it.");
    String rev = kbReader.nextLine();
    p.println("Review of " + showtitle + ": " + rev + "\n\n");
    System.out.println("Your review of " + showtitle + " was successfully added!");
    p.close();  //must close to avoid resource leaks
    kbReader.close();
    genreSelect();
  } 
  
  /* void return type & no parameters 
   * fuction of addFave() is to add name of show to Favorites List 
   */
  public void addFave() throws IOException 
  {
    
    Scanner kbReader = new Scanner(System.in); 
    
    String showtitle = returnTitle();
    Scanner findfave = new Scanner(new File(user + "_Favorites.txt"));
    FileWriter forfave = new FileWriter(user + "_Favorites.txt", true);
    PrintWriter printfave = new PrintWriter(forfave);  
    boolean favelist = findfave.hasNext();
    if(!favelist){
      printfave.println(showtitle);
      System.out.println(showtitle + " was successfully added to your list!\n");
    }
    else if(favelist) {
      String favefound = findfave.nextLine();
      boolean showFound = showtitle.equals(favefound);
      if(showFound){
        System.out.println(showtitle + " is already in your Favorites list.\n");
      }
      else if(!showFound){
        printfave.println(showtitle);
        System.out.println(showtitle + " was successfully added to your list!\n"); 
      }
    }
    printfave.close();  
    findfave.close();
    kbReader.close();
    genreSelect(); 
  } 
  
  Scanner kbReader = new Scanner(System.in); 
  
  /* showChoices has no parameters & void return type
   * purpose is to display options to write review/add to favorites if user is logged in
   * */
  
  public void showChoices() throws IOException {
    if(UserMethods.returnAU()) //is user logged in
    {
      System.out.println("\nType 'A' to write a review, 'B' to add this show to favorites, or 'C' to return to the genre list."); 
      String choose = kbReader.next();
      char x = choose.charAt(0);      
      switch(x) {
        case 'A':
        case 'a':
          addReview();
          break;
        case 'B':
        case 'b':
          addFave();
          break;
        case 'C':
        case 'c':
          genreSelect();
          break;
      }
    } 
    else{ 
      System.out.println("\nOnly registered members can write reviews and add shows to Favorites."); 
      System.out.println("Type any key to return to the genre list.");
      kbReader.next();
      genreSelect();
    }
  }
  /*
   * tvData - parameter corresponds to user's show choice and is used in case statement
   * void return type
   * traverse through file and print desired show's information
   *  */
  String showTitle = "";
  public void tvData(int choiceNumber) throws IOException
  {
    
    Scanner tvfile = new Scanner(new File("TVShowsList.txt"));
    for(int count = 0; count <= (choiceNumber-1) && tvfile.hasNextLine(); count++){ 
      if((choiceNumber-1) == count){ 
        showTitle = tvfile.nextLine();
        String showGenre = tvfile.nextLine();
        String showYear = tvfile.nextLine();
        String showSum = tvfile.nextLine();
        String showSource = tvfile.nextLine();

        Nodes showNode = new Nodes(showTitle, showGenre, showYear, showSum, showSource, null);
        System.out.println("Title: " + showNode.name);
        System.out.println("Genre: " + showNode.genre);
        System.out.println("Status: " + showNode.status);
        System.out.println("Summary: " + showNode.summary);
        System.out.println("Source: " + showNode.source); 
        
      } 
      else {
        tvfile.nextLine(); //skip past unwanted show's title
        tvfile.nextLine(); //skip past unwanted show's genre
        tvfile.nextLine(); //skip past unwanted show's status
        tvfile.nextLine(); //skip past unwanted show's summary
        tvfile.nextLine(); //skip past unwanted show's source
        tvfile.nextLine(); //skip past unwanted show's divider
      }
    }
    tvfile.close();
  }
  public String returnTitle(){
    return showTitle; 
  }
  
  public void genreSelect() throws IOException
  {        
    System.out.println("Choose a genre by entering the corresponding number, or return to the homepage. \n");
    
    System.out.println("0. Return to home");
    System.out.println("1. Action/Adventure");
    System.out.println("2. Cartoons/Animated Series");
    System.out.println("3. Comedy");
    System.out.println("4. Crime & Mystery");
    System.out.println("5. Romance & Drama");
    System.out.println("6. Historical/Period Dramas");
    System.out.println("7. Korean Dramas");
    System.out.println("8. Science Fiction & Fantasy");
    
    System.out.println("\nYour choice? ");
    int genres = kbReader.nextInt();
    
    try{ 
      switch(genres)
      {
        case 0:
          MyTVTracker.firstMethod(); //must be accessed in a static way rather than use object 
          break;
        case 1: 
          System.out.println("Select a television program to view its information or add it to a list.");
          System.out.println("You may also return to the list of genres. \n");
          
          System.out.println("0. Return to genre list.");
          System.out.println("1. Agent Carter");
          System.out.println("2. Agents of S.H.I.E.L.D.");
          System.out.println("3. Arrow");
          System.out.println("4. Daredevil");
          System.out.println("5. Jessica Jones");
          System.out.println("6. Luke Cage");
          System.out.println("7. The Flash");
          System.out.println("8. The 100");
          System.out.println("9. Supergirl");
          
          System.out.println("\nYour choice? ");
          num = kbReader.nextInt(); 
          switch(num)
          {
            case 0:
              genreSelect();
              break;         
            case 1:
              tvData(num);
              showChoices();
              break;
            case 2:
              tvData(num);
              showChoices();
              break;
            case 3:
              tvData(num);
              showChoices();
              break;
            case 4:
              tvData(num);
              showChoices();
              break;
            case 5:
              tvData(num);
              showChoices();
              break;
              
            case 6:
              tvData(num);
              showChoices();
              break;
            case 7:
              tvData(num);
              showChoices();
              break;
            case 8:
              tvData(num);
              showChoices();
              break;
            case 9:
              tvData(num);
              showChoices();
              break;
            default:                
              System.out.println("Please select a valid number.");
              genreSelect();   
          }
          break;
          
        case 2:       
          System.out.println("Select a television program to view its information or add it to a list."); 
          System.out.println("You may also return to the list of genres. \n");
          
          System.out.println("0. Return to genre list.");
          System.out.println("1. Adventure Time");
          System.out.println("2. Gravity Falls");
          System.out.println("3. Miraculous: Tales of Ladybug & Cat Noir");
          System.out.println("4. Over the Garden Wall");
          System.out.println("5. Star Vs. the Forces of Evil");
          System.out.println("6. Steven Universe");
          System.out.println("7. The Legend of Korra");
          System.out.println("8. Voltron: Legendary Defender");
          System.out.println("9. Young Justice");
          
          System.out.println("\nYour choice? ");
          int cartoon = kbReader.nextInt();
          num = (cartoon + 9);
          switch(num)
          {
            case 9:
              genreSelect();
              break;          
            case 10:
              tvData(num);
              showChoices();
              break;
            case 11:
              tvData(num);
              showChoices();
              break;
            case 12:
              tvData(num);
              showChoices();
              break;
            case 13:
              tvData(num);
              showChoices();
              break;
            case 14:
              tvData(num);
              showChoices();
              break;
              
            case 15:
              tvData(num);
              showChoices();
              break;
            case 16:
              tvData(num);
              showChoices();
              break;
            case 17:
              tvData(num);
              showChoices();
              break;
            case 18:
              tvData(num);
              showChoices();
              break;
            default:                
              System.out.println("Please select a valid number.");
              genreSelect();
          }
          break;
        case 3:
          System.out.println("Select a television program to view its information or add it to a list.");
          System.out.println("You may also return to the list of genres. \n");
          
          System.out.println("0. Return to genre list.");
          System.out.println("1. Bob's Burgers");
          System.out.println("2. Black-ish");
          System.out.println("3. Faking It");
          System.out.println("4. Fresh Off the Boat");
          System.out.println("5. Modern Family");
          System.out.println("6. New Girl");
          System.out.println("7. Parks and Recreation");
          System.out.println("8. The Office");
          System.out.println("9. Young & Hungry");
          
          
          System.out.println("\nYour choice? ");
          input = kbReader.nextInt();
          num = (input + 18);
          switch(num)
          {
            case 18:
              genreSelect();
              break;
              
            case 19:
              tvData(num);
              showChoices();
              break;
            case 20:
              tvData(num);
              showChoices();
              break;
            case 21:
              tvData(num);
              showChoices();
              break;
            case 22:
              tvData(num);
              showChoices();
              break;
            case 23:
              tvData(num);
              showChoices();
              break;
              
            case 24:
              tvData(num);
              showChoices();
              break;
            case 25:
              tvData(num);
              showChoices();
              break;
            case 26:
              tvData(num);
              showChoices();
              break;
            case 27:
              tvData(num);
              showChoices();
              break;
            default:               
              System.out.println("Please select a valid number.");
          }
          break;
        case 4:
          System.out.println("Select a television program to view its information or add it to a list.");
          System.out.println("You may also return to the list of genres. \n");
          
          System.out.println("0. Return to genre list.");
          System.out.println("1. A Series of Unfortunate Events");
          System.out.println("2. Criminal Minds");
          System.out.println("3. Elementary");
          System.out.println("4. Gotham");
          System.out.println("5. How to Get Away With Murder");
          System.out.println("6. iZombie");
          System.out.println("7. Riverdale");
          System.out.println("8. Sherlock");
          System.out.println("9. Sweet Vicious");
          
          System.out.println("\nYour choice? ");
          input = kbReader.nextInt();
          num = (input + 27);
          
          switch(num)
          {
            case 27:
              genreSelect();
              break;
              
            case 28:
              tvData(num);
              showChoices();
              break;
            case 29:
              tvData(num);
              showChoices();
              break;
            case 30:
              tvData(num);
              showChoices();
              break;
            case 31:
              tvData(num);
              showChoices();
              break;
            case 32:
              tvData(num);
              showChoices();
              break;
              
            case 33:
              tvData(num);
              showChoices();
              break;
            case 34:
              tvData(num);
              showChoices();
              break;
            case 35:
              tvData(num);
              showChoices();
              break;
            case 36:
              tvData(num);
              showChoices();
              break;
            default:                
              System.out.println("Please select a valid number.");
              genreSelect();
          }          
          break;
        case 5:  
          System.out.println("Select a television program to view its information or add it to a list.");
          System.out.println("You may also return to the list of genres. \n");
          System.out.println("0. Return to genre list.");
          System.out.println("1. Awkward");
          System.out.println("2. Crazy Ex-Girlfriend");
          System.out.println("3. Empire");
          System.out.println("4. Gossip Girl");
          System.out.println("5. Grey's Anatomy");
          System.out.println("6. Pretty Little Liars");
          System.out.println("7. The Fosters");
          System.out.println("8. The Good Fight");
          System.out.println("9. Yuri On Ice");
          
          System.out.println("\nYour choice? ");
          input = kbReader.nextInt();
          num = (input + 36);
          
          switch(num)
          {
            case 36:
              genreSelect();
              break;
              
            case 37:
              tvData(num);
              showChoices();
              break;
            case 38:
              tvData(num);
              showChoices();
              break;
            case 39:
              tvData(num);
              showChoices();
              break;
            case 40:
              tvData(num);
              showChoices();
              break;
            case 41:
              tvData(num);
              showChoices();
              break;
              
            case 42:
              tvData(num);
              showChoices();
              break;
            case 43:
              tvData(num);
              showChoices();
              break;
            case 44:
              tvData(num);
              showChoices();
              break;
            case 45:
              tvData(num);
              showChoices();
              break; 
            default:                          
              System.out.println("Please select a valid number.");
          }
          break;
          
        case 6:
          System.out.println("Select a television program to view its information or add it to a list.");
          System.out.println("You may also return to the list of genres. \n");
          
          System.out.println("0. Return to genre list.");
          System.out.println("1. Downton Abbey");
          System.out.println("2. Medici: Masters of Florence");
          System.out.println("3. Peaky Blinders");
          System.out.println("4. Reign");
          System.out.println("5. The Borgias");
          System.out.println("6. The Crown");
          
          System.out.println("\nYour choice? ");
          input = kbReader.nextInt();
          num = (input + 45);
          
          switch(num)
          {
            case 45:
              genreSelect();
              break;
              
            case 46:
              tvData(num);
              showChoices();
              break;
            case 47:
              tvData(num);
              showChoices();
              break;
            case 48:
              tvData(num);
              showChoices();
              break;
            case 49:
              tvData(num);
              showChoices();
              break;
            case 50:
              tvData(num);
              showChoices();
              break;
              
            case 51:
              tvData(num);
              showChoices();
              break;
            default:                
              System.out.println("Please select a valid number.");
              genreSelect();
          }
          break; 
          
        case 7:                 
          System.out.println("Select a television program to view its information or add it to a list.");
          System.out.println("You may also return to the list of genres. \n");
          
          System.out.println("0. Return to genre list.");
          System.out.println("1. Cheese in the Trap");
          System.out.println("2. Descendants of the Sun");
          System.out.println("3. Doctors");
          System.out.println("4. Emergency Couple");
          System.out.println("5. My Love From Another Star");
          System.out.println("6. Monster");
          
          System.out.println("\nYour choice? ");
          input = kbReader.nextInt();
          num = (input + 51);
          
          switch(num)
          {
            case 51:
              genreSelect();
              break;
              
            case 52:
              tvData(num);
              showChoices();
              break;
            case 53:
              tvData(num);
              showChoices();
              break;
            case 54:
              tvData(num);
              showChoices();
              break;
            case 55:
              tvData(num);
              showChoices();
              break;
            case 56:
              tvData(num);
              showChoices();
              break;
              
            case 57:
              tvData(num);
              showChoices();
              break;
          }       
          break;
          
        case 8:
          System.out.println("Select a television program to view its information or add it to a list.");
          System.out.println("You may also return to the list of genres. \n");
          
          System.out.println("0. Return to genre list.");
          System.out.println("1. Almost Human");
          System.out.println("2. Dark Matter");
          System.out.println("3. Galavant");
          System.out.println("4. Game of Thrones");
          System.out.println("5. Mr. Robot");
          System.out.println("6. Once Upon A Time");
          System.out.println("7. Shadowhunters");
          System.out.println("8. The OA");
          System.out.println("9. The Shannara Chronicles");
          
          System.out.println("\nYour choice? ");
          input = kbReader.nextInt();
          num = (input + 57);       
          switch(num)
          {
            case 57:
              genreSelect();
              break;
              
            case 58:
              tvData(num);
              showChoices();
              break;
            case 59:
              tvData(num);
              showChoices();
              break;
            case 60:
              tvData(num);
              showChoices();
              break;
            case 61:
              tvData(num);
              showChoices();
              break;
            case 62:
              tvData(num);
              showChoices();
              break;         
            case 63:
              tvData(num);
              showChoices();
              break;
            case 64:
              tvData(num);
              showChoices();
              break;
            case 65:
              tvData(num);
              showChoices();
              break;
            case 66:
              tvData(num);
              showChoices();
              break;
            default:       
              System.out.println("Please select a valid number.");
          }
          break;
          
      } 
    }
    catch(InputMismatchException e)
    {
      System.out.println("Invalid input. Please try again.");
      genreSelect();
    } 
    kbReader.close();
  }
}

