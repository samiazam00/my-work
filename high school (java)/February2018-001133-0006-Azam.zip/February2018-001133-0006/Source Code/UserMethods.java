import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;


public class UserMethods
{
  File checkfile = new File("TVLogIn.txt");
  static String user = "";
  public static String returnUser(){
   return user; 
  }
  public void signUpMethod() throws IOException
  {
     Scanner kbReader = new Scanner(System.in);
     FileWriter fw = new FileWriter("TVLogIn.txt", true);
     PrintWriter pw = new PrintWriter(fw); 
     
     File f = new File("TVLogIn.txt");
     Scanner txtfile = new Scanner(f);
     System.out.println("Username: ");
     user = kbReader.nextLine();
     
     while(user.length() < 4)
     { 
       System.out.println("Usernames must be at least 4 characters. Please try again"); 
       System.out.println("Username: ");
       user = kbReader.nextLine(); 
     }
     String checkuser = "";
     while(txtfile.hasNext()) {
       checkuser = txtfile.next(); //read only the first word of the line (only username)
       while(checkuser.equals(user)) {
         System.out.println("Sorry! This username already exists. Please try again.");
         signUpMethod();
       }
     }
     pw.print("\n" + user + "\t");
       
     System.out.println("Password: ");
     String pass = kbReader.nextLine(); 
     while(pass.length() <= 3)
     { System.out.println("Passwords must be at least 4 characters.");
       System.out.println("Password: ");
       pass = kbReader.nextLine(); }
     pw.println(pass);       
     File favoritefile = new File(user + "_Favorites.txt");
     favoritefile.createNewFile();
     /*File showsfile = new File(user + "_Shows.txt"); 
     showsfile.createNewFile();  */
     File reviewfile = new File(user + "_Reviews.txt");
     reviewfile.createNewFile(); 
     
     pw.close();
     fw.close();
     txtfile.close();
     System.out.println("Thanks for signing up! You will now be directed to the log-in page.");
     kbReader.close();
     UserMethods z = new UserMethods();
     z.loggingIn();
  }
  public static boolean activeUser = false;
  public static boolean returnAU(){ 
     return activeUser; }   
 
  Scanner kbReader = new Scanner(System.in);
  ProgramMethods gens = new ProgramMethods();
  MyTVTracker homepage = new MyTVTracker();

  public void whenLoggedIn() throws IOException {
     System.out.println("This is your account page, where you may view your reviews and list of favorite shows.\n");
     Scanner faveRead = new Scanner(new File(user + "_Favorites.txt"));
     Scanner revRead = new Scanner(new File(user + "_Reviews.txt"));
     boolean faveList = faveRead.hasNextLine();
     boolean revs = revRead.hasNextLine();
     
     if(faveList == true) {
       System.out.println("Your Favorite Shows:");
       while(faveRead.hasNextLine())
       { 
         String fav = faveRead.nextLine();
         System.out.println(fav);  
       }
     }
     else 
       System.out.println("You don't have any favorite shows yet! Feel free to add shows to your list."); 
     
     if(revs == true) {
       System.out.println("\nYour Reviews:\n");
       while(revRead.hasNextLine())
       { 
         String revlist = revRead.nextLine();
         System.out.println(revlist); 
       }
     }
     else 
       System.out.println("\nYou haven't written any reviews yet! Feel free to write reviews for shows as you browse."); 
     
     System.out.println("\nPress any key to return to the homepage.");
     kbReader.next();
     MyTVTracker.firstMethod(); //must be accessed in a static way rather than use object 
     
     faveRead.close();
     revRead.close();
  }
  
  public void loggingOut(){
    activeUser = false;
    System.out.println("\nYou have logged out! You will now be directed to the homepage. \n");
  }
   
  public void loggingIn() throws IOException {       
    if(checkfile.exists())
    {  
       Scanner fileRead = new Scanner(new File("TVLogIn.txt"));
       System.out.println("Please enter your login information.");
       System.out.println("Username:");
       String enterUser = kbReader.nextLine();
       System.out.println("Password:");
       String enterPass = kbReader.nextLine();
       String infoEntered = (enterUser + "\t" + enterPass);  
   
       while(fileRead.hasNextLine() && !activeUser) {
         String nextLn = fileRead.nextLine();
         if(infoEntered.equals(nextLn))
         { 
           activeUser = true;
           user = enterUser;
           System.out.println("Login successful! You will now return to the homepage.");
           MyTVTracker.firstMethod(); //must be accessed in a static way rather than use object 
           }
       }
       if(!activeUser)
       {
          System.out.println("Incorrect username or password, please try again.");
          loggingIn();
       }
      fileRead.close();
      kbReader.close();     
    }
  else 
    System.out.println("Please sign up before logging in.\n\nPlease create your username and password. Usernames and passwords should be at least 4 characters, and cannot include spaces."); 
    signUpMethod();
  }
}