import java.util.Scanner;
import java.io.IOException;
import java.io.File;

public class MyTVTracker
{   
  public static void firstMethod() throws IOException 
  {
    String user = UserMethods.returnUser(); //calls returnUser method of UserMethods class & stores client's username in String
    boolean isActiveUser = UserMethods.returnAU(); //boolean that determines whether user is logged in 
    UserMethods userActions = new UserMethods(); //create object of UserMethods 
    ProgramMethods callShows = new ProgramMethods(); //create object of ProgramMethods
    BinarySearch search = new BinarySearch(); //create object of BinarySearch
    
    if(isActiveUser){ //if user is logged in, these options are displayed:
      System.out.println("Hello, " + user + "! You may view your account information, log out of your account, browse through show information, or recieve a random recommendation.");
      System.out.println("A. My Account");
      System.out.println("B. Log Out");
    }
    
    else{ //not logged in:
      System.out.println("You may sign up to create an account, log in, browse through show information, or receive a random recommendation.");
      System.out.println("A. Sign Up");
      System.out.println("B. Log In"); 
    }  
    
    System.out.println("C. View All Shows"); //can be viewed/accessed by anyone
    System.out.println("D. Randomizer");
    System.out.println("E. Search for Shows");
   /* if(isActiveUser) //only logged in users can see this option
    {
      System.out.println("F. Add a Show"); 
    } */
    System.out.println("\nYour choice? ");
    
    Scanner kbReader = new Scanner(System.in);
    String firstChoice = kbReader.nextLine();
    switch(firstChoice.charAt(0))
    { 
      case 'A': //use both upper & lower case for case statements for user's convenience
      case 'a':
      if(isActiveUser)
      { 
        userActions.whenLoggedIn();
      }
        else{  
          System.out.println("Please create your username and password. Usernames and passwords should be at least 4 characters, and cannot include spaces.");  
          userActions.signUpMethod(); 
          userActions.loggingIn();
        }
        break;
      case 'B':
      case 'b':         
        if(isActiveUser) //if logged in
        {
        userActions.loggingOut(); //cal logging out method
        firstMethod(); //return to homepage
        }
        else{
          userActions.loggingIn(); //not logged in, so calls Log In method
        }
        break;
      case 'C':
      case 'c':
        callShows.genreSelect(); 
        break;
      case 'D':
      case 'd':
        callShows.randomShows();  
        firstMethod();
        break;
      case'E':
      case 'e':
        Scanner showInfo = new Scanner(new File("TVShowsList.txt"));
        int x = 0;
        String storeAll[] = new String[66];
        while(showInfo.hasNextLine())
        { 
          String title = showInfo.nextLine();
          showInfo.nextLine();  //skip unnecssary info
          showInfo.nextLine();
          showInfo.nextLine();
          showInfo.nextLine();
          showInfo.nextLine(); //skip divider
          Nodes tvNode = new Nodes(title, null);
          Stack.push(tvNode);
          storeAll[x] = title;
          x++;
        }
          search.searchShow(storeAll);
          break;
      default:
        System.out.println("Please choose a letter from the options listed above.");
        firstMethod();  
    }
    kbReader.close();
  }
  
  public static void main(String args[]) throws IOException 
  {
    System.out.println("Welcome! This application provides information and recommendations about current TV shows."); 
    try{
      firstMethod();
    }
    catch(StringIndexOutOfBoundsException e) //in case invalid input is entered, user can try again
    {
      System.out.println("Invalid input. Please try again.");
      firstMethod();
    }
  }
}
