public class Nodes  extends Stack {
  //Fields:
  public String name; //name of TV show
  public String genre; //shows's genre
  public String status; //whether show is ongoing/completed + year it began
  public String summary; //summary of show
  public String source; //source of summary info
  public Nodes nextNode; //pointer to next node in list
   
public Nodes(String addShowName, Nodes pointer) //Constructor: no parameters, used to only add name of show 
{
    name = addShowName;
    nextNode = pointer;
}

  
public Nodes(String n, String gen, String year, String sum, String src, Nodes ptr) //Constructor: adding a show & its information
   {
    name = n;
    genre = gen;
    status = year;
    summary = sum;
    source = src;
    nextNode = ptr;
   }

}
