import java.util.Scanner;
import java.io.IOException;
import java.io.File;
import java.util.Arrays;

public class BinarySearch
{
  public void searchShow(String [] showsToSearch) throws IOException
  {
    Arrays.sort(showsToSearch);
    Scanner kbReader = new Scanner(System.in);
    int lowIndx = 0;
    int highIndx = showsToSearch.length-1;
    int midIndx = 0;
    System.out.println("Type below to search for a particular show. Show names are case-sensitive.");
    String keyword = kbReader.nextLine(); 
    
    while(lowIndx <= highIndx) 
    {
      midIndx = (lowIndx + highIndx) /2; //middle value between lowest and highest, determines what we can skip
      if(keyword.compareTo(showsToSearch[midIndx]) > 0) //based on ASCII values, determine if larger section should be eliminated
      {
        lowIndx = midIndx+ 1; //lower half is gone, now check again
      }
      else if(keyword.compareTo(showsToSearch[midIndx]) < 0) //determine if smaller half should be eliminated
      {
        highIndx = midIndx - 1; //larger half gone, check again
      }
      else
        break; //not found   
    }
    
    if(lowIndx > highIndx){
      System.out.println("Search term was not found!");
    }
    else
    {
      Scanner checkSearch = new Scanner(new File("TVShowsList.txt"));
      while(checkSearch.hasNextLine())
      {
        String title = checkSearch.nextLine(); 
        if(title.equalsIgnoreCase(keyword))
        {
          System.out.println(title);
          System.out.println(checkSearch.nextLine()); 
          System.out.println(checkSearch.nextLine());
          System.out.println(checkSearch.nextLine());
          System.out.println(checkSearch.nextLine());
          checkSearch.nextLine(); //skip divider
        }
        else
        { //skip
          checkSearch.nextLine();
          checkSearch.nextLine();
          checkSearch.nextLine();
          checkSearch.nextLine();
          checkSearch.nextLine();
        }
      }
      checkSearch.close();
    }    
    kbReader.close();
  }
}